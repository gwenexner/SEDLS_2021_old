<template>
  <Layout>
    <h1 class="text-3xl">Commitment to Accessibility</h1>
    <p class="mt-4">
      The Southeast Data Librarian Symposium planning committee is an intentional ally of accessibility. We are committed to providing a learning environment rooted in openness, inclusion, and opportunity. The following are ways in which we honor our commitment:
    </p>
    <h2 class="text-2xl mt-4">Zoom</h2>
    <ul class="mt-4 ml-8 list-disc list-outside">
      <li>Live transcription will be enabled for all Zoom meetings. Participants will have the ability to enable/disable captioning on their device in Zoom.</li>
      <li>Zoom is compatible with the following screen readers: VoiceOver on iOS and OSX, Talkback on Android devices, and JAWS and NVDA for Windows platforms.</li>
      <li>All short talks will be recorded, captioned/transcribed, and shared along with any additional notes and presentation materials once the symposium is over.</li>
      <li>We acknowledge that Discord has limited options for accessibility and will provide access to symposium proceedings and social events and share information and materials via multiple avenues, including Zoom, Discord, and email.</li>
    </ul>
    <h2 class="text-2xl mt-4">Attendees</h2>
    <ul class="mt-4 ml-8 list-disc list-outside">
      <li>Please ensure you are participating from a quiet location with minimal background noise and remain muted unless you are asking a question or engaging in discussion.</li>
      <li>Attendees who use audio to ask questions or engage in discussion should identify themselves and speak slowly and clearly.</li>
    </ul>
    <h2 class="text-2xl mt-4">Presenters</h2>
    <ul class="mt-4 ml-8 list-disc list-outside">
      <li>Presenters should provide virtual access copies of your presentations, using 16pt font, in advance for audience members.
      </li>
      <li>If you use images in your presentation and/or handouts, please provide a brief verbal and text description of what the image contains, alongside the context and intention of the images. If a screen is being shared, describe the visuals as required.</li>
      <li>Presenters should always identify themselves and speak slowly and clearly.</li>
      <li>When choosing the slide and text colors of your presentation, please choose high contrast colors (e.g. black text on white background) for best visibility.</li>
      <li>During your presentation, please repeat names and questions during Q&#38;A.</li>
      <li>During your presentation please be mindful of not covering your face/mouth.</li>
    </ul>
  </Layout>
</template>

<script>
export default {
  metaInfo: {
    title: 'Accessibility'
  }
}
</script>

<style>

</style>